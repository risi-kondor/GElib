#ifndef _CnineStandardYoungTableau
#define _CnineStandardYoungTableau

#include "YoungTableau.hpp"

namespace cnine{

  class StandardYoungTableau: public YoungTableau{
  public:

    using YoungTableau::YoungTableau;



  public:


  };

}

#endif
